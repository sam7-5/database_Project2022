-- Create/Recreate indexes 
create index INDEXONDATE on ORDERS (Date_Of_Orders);
