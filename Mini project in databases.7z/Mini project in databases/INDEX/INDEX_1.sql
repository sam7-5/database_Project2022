-- Create/Recreate indexes 
create index bl on CUSTOMERS (security_deposit, black_list);
