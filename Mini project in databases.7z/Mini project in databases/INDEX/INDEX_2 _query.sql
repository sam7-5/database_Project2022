select Extras ,count(*)
from Orders
group by Extras
