select *
from Orders
where Extras = 'Booster';