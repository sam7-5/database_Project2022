Update Orders 
set Extras  = NULL 
where Extras  = 'Nothing';
