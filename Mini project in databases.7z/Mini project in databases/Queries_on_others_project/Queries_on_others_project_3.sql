select PAYMENTS,count(*)
from ELAFISHE.ORDERS
group by PAYMENTS
