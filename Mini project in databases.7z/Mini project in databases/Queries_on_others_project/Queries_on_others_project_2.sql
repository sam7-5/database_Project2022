select *
from ELAFISHE.ORDERS
where costumer_id = &costumer_id;
